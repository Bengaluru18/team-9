<!DOCTYPE html>
<html lang="en">
<head>
  <title>Carewroks Foundation</title>
  <style>
  body {
     background-image: url("cwf.png");
     background-color: #cccccc;
     background-repeat: no-repeat;
     background-size:auto;
     background-position:bottom;

  }
     .container h1{
            color: teal;
            font-family: Montserrat,sans-serif;
        }
      .container  h2{
            color: tomato;
            font-family: Montserrat,sans-serif;
        }
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body background image>

<div class="container">
  <h1 align="center">Careworks Foundation</h1>
  <h2 align="center">SCHOOL DETAILS</h2>
  <form action="insert.php">
    <div class="form-group">
      <label for="sid">School ID:..........</label>
      
    </div>
	 <div class="form-group">
      <label for="sid">School Name:..........</label>
      
    </div>
    <div class="form-group">
      <label for="sid">Locality:............</label>
      
    </div>
	 <div class="form-group">
      <label for="sid">Address:..........</label>
      
    </div>
	 <div class="form-group">
      <label for="sid">Total Classes:..........</label>
      
    </div>
	 <div class="form-group">
      <label for="sid">Medium of Instruction:..........</label>
      
    </div>
      <div class="form-group">
      <label for="sid">Head Master's Name:...............</label>
      
    </div>
      <div class="form-group">
      <label for="sid">Phone Number:....................</label>
</div>
	
       <div class="form-group">
      <label for="sid">Teacher Mentorship:..........</label>
      <br />
    </div>
     <div class="form-group">
      <label for="sid">Stakeholder Engagement:..........</label>
	 
    </div>
      <div class="form-group">
      <label for="computer">Number of Computers:.........</label>
      
    </div>
    <div class="form-group">
      <label for="library">Is Library Arranged:.YES/NO</label><br>
          </div>
    <div class="form-group">
      <label for="science">Are Chemicals available in Labs:.YES/NO</label><br>
     
    </div>
    <div class="form-group">
      <label for="water">Storage Facility for Drinking Water:..YES/NO</label><br>
      
    </div>
    <div class="form-group">
      <label for="toilet">Sanitation Facility:..YES/NO</label><br>
     
    </div>
    <div class="form-group">
      <label for="handwash">Handwash/Restrooms Area:..YES/NO</label><br>
      
    </div>
    <div class="form-group">
      <label for="handwash">Any NGO involved?:..YES/NO</label><br>
     
    </div>
    <div class="form-group">
      <label for="handwash">Are any health services provided free?: ..YES/NO</label><br>
    
    </div>
	<div class="form-group">
      <label for="handwash">Flooring Condition:.....</label><br />
</div>
<div class="form-group">
      <label for="handwash">Plastering Condition:....</label><br>
    
    </div>
<div class="form-group">
      <label for="handwash">Waterproofing:...</label><br>
    
   </div>
	
	<div class="form-group">
      <label for="handwash">Painting:....</label><br>
    
    </div>
	<div class="form-group">
      <label for="handwash">Renovation required:...</label><br />
    
    </div>
<div class="form-group">
      <label for="handwash">Requires Approval?:...</label><br />
    
    </div>
    <br />
    
      <br>
  </form>
</div>

</body>
</html>
